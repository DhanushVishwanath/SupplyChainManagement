
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdminModule extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton clientRequirementsButton;
    private JButton dealerInformationButton;
    private JButton inventoryButton;
    private JButton ordersPlacedButton;
    private JButton logoutButton;

    private String adminUsername = "admin"; 
    private String adminPassword = "admin"; 

    public AdminModule() {
        setTitle("Admin Module");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel loginPanel = createLoginPanel();
        JPanel adminOptionsPanel = createAdminOptionsPanel();

        setLayout(new BorderLayout());
        add(loginPanel, BorderLayout.NORTH);
        add(adminOptionsPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    private JPanel createLoginPanel() {
        JPanel loginPanel = new JPanel(new GridLayout(3, 2));

        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);

        loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });

        loginPanel.add(new JLabel("Username:"));
        loginPanel.add(usernameField);
        loginPanel.add(new JLabel("Password:"));
        loginPanel.add(passwordField);
        loginPanel.add(loginButton);

        return loginPanel;
    }

    private JPanel createAdminOptionsPanel() {
        JPanel adminOptionsPanel = new JPanel(new GridLayout(5, 1));

        clientRequirementsButton = new JButton("Client Requirements");
        clientRequirementsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewClientRequirements();
            }
        });

        dealerInformationButton = new JButton("Dealer Information");
        dealerInformationButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewDealerInformation();
            }
        });

        inventoryButton = new JButton("Inventory");
        inventoryButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewInventory();
            }
        });

        ordersPlacedButton = new JButton("Orders Placed");
        ordersPlacedButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                viewOrdersPlaced();
            }
        });

        logoutButton = new JButton("Logout");
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logout();
            }
        });

        adminOptionsPanel.add(clientRequirementsButton);
        adminOptionsPanel.add(dealerInformationButton);
        adminOptionsPanel.add(inventoryButton);
        adminOptionsPanel.add(ordersPlacedButton);
        adminOptionsPanel.add(logoutButton);

        adminOptionsPanel.setVisible(false);

        return adminOptionsPanel;
    }

    private void login() {
        String enteredUsername = usernameField.getText();
        char[] enteredPassword = passwordField.getPassword();
    
        try (Connection connection = DatabaseManager.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "SELECT * FROM AdminCredentials WHERE username = ? AND password = ?")) {
    
            preparedStatement.setString(1, enteredUsername);
            preparedStatement.setString(2, new String(enteredPassword));
    
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                JOptionPane.showMessageDialog(this, "Login successful!");
                getContentPane().getComponent(1).setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password. Please try again.");
            }
    
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error during login.");
        }
    
        passwordField.setText("");
    }

    private void viewClientRequirements() {
        try (Connection connection = DatabaseManager.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM ClientAdminRequests")) {
    
            ResultSet resultSet = preparedStatement.executeQuery();
            StringBuilder clientRequirements = new StringBuilder("Client Requirements:\n");
            while (resultSet.next()) {
                clientRequirements.append("ID: ").append(resultSet.getInt("id"))
                        .append(", Client Name: ").append(resultSet.getString("clientName"))
                        .append(", Phone Number: ").append(resultSet.getString("phoneNumber"))
                        .append(", Product Name: ").append(resultSet.getString("productName"))
                        .append(", Quantity: ").append(resultSet.getInt("quantity"))
                        .append("\n");
            }
            JOptionPane.showMessageDialog(this, clientRequirements.toString());
    
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error retrieving information: " + e.getMessage());
        }
    }
    

    private void viewDealerInformation() {
        try (Connection connection = DatabaseManager.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM DealerAdminRequests")) {
    
            ResultSet resultSet = preparedStatement.executeQuery();
    
            if (!resultSet.isBeforeFirst()) {
                JOptionPane.showMessageDialog(this, "No dealer information available.");
                return;
            }
            StringBuilder dealerInformation = new StringBuilder("Dealer Information:\n");
            while (resultSet.next()) {
                dealerInformation.append("ID: ").append(resultSet.getInt("id"))
                        .append(", Dealer Name: ").append(resultSet.getString("dealerName"))
                        .append(", Phone Number: ").append(resultSet.getString("phoneNumber"))
                        .append(", Product Name: ").append(resultSet.getString("productName"))
                        .append(", Quantity: ").append(resultSet.getInt("quantity"))
                        .append("\n");
            }
            JOptionPane.showMessageDialog(this, dealerInformation.toString());
    
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error retrieving information: " + e.getMessage());
        }
    }
    
    
    

    private void viewInventory() {
        try (Connection connection = DatabaseManager.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "SELECT c.*, d.* FROM ClientAdminRequests c JOIN DealerAdminRequests d ON c.productName = d.productName AND c.quantity <= d.quantity")) {
    
            ResultSet resultSet = preparedStatement.executeQuery();
            // Process the result set and display the inventory information
            // Example: Displaying in a JOptionPane for demonstration purposes
            StringBuilder inventoryInformation = new StringBuilder("Inventory Information:\n");
            while (resultSet.next()) {
                inventoryInformation.append("Client ID: ").append(resultSet.getInt("c.id"))
                        .append(", Client Name: ").append(resultSet.getString("c.clientName"))
                        .append(", Dealer ID: ").append(resultSet.getInt("d.id"))
                        .append(", Dealer Name: ").append(resultSet.getString("d.dealerName"))
                        .append(", Product Name: ").append(resultSet.getString("c.productName"))
                        .append(", Quantity: ").append(resultSet.getInt("c.quantity"))
                        .append("\n");
            }
            JOptionPane.showMessageDialog(this, inventoryInformation.toString());
    
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error retrieving information: " + e.getMessage());
        }
    }
    
    private void viewOrdersPlaced() {
        try (Connection connection = DatabaseManager.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT c.*, d.* FROM ClientAdminRequests c JOIN DealerAdminRequests d ON c.productName = d.productName AND c.quantity <= d.quantity")) {

            ResultSet resultSet = preparedStatement.executeQuery();
            // Process the result set and display the orders placed information
            // Example: Displaying in a JOptionPane for demonstration purposes
            StringBuilder ordersPlacedInformation = new StringBuilder("Orders Placed:\n");
            while (resultSet.next()) {
                ordersPlacedInformation.append("Client ID: ").append(resultSet.getInt("c.id"))
                .append(", Client Name: ").append(resultSet.getString("c.clientName"))
                .append(", Dealer ID: ").append(resultSet.getInt("d.id"))
                .append(", Dealer Name: ").append(resultSet.getString("d.dealerName"))
                .append(", Product Name: ").append(resultSet.getString("c.productName"))
                .append(", Quantity: ").append(resultSet.getInt("c.quantity"))
                .append("\n");
            }
            JOptionPane.showMessageDialog(this, ordersPlacedInformation.toString());

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error retrieving information: " + e.getMessage());
        }
    }

    private void logout() {
        getContentPane().getComponent(1).setVisible(false);
        usernameField.setText("");
        passwordField.setText("");
        JOptionPane.showMessageDialog(this, "Logged out successfully!");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new AdminModule();
            }
        });
    }
}
