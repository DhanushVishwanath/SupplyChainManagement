
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClientModule extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton createAccountButton;

    private JTextField clientNameField;
    private JTextField phoneNumberField;
    private JTextField productNameField;  
    private JTextField quantityField;
    private JButton sendToAdminButton;
    private JButton logoutButton;

    private String currentClientUsername;

    public ClientModule() {
        setTitle("Client Module");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel loginPanel = createLoginPanel();
        JPanel clientInputPanel = createClientInputPanel();

        setLayout(new BorderLayout());
        add(loginPanel, BorderLayout.NORTH);
        add(clientInputPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    private JPanel createLoginPanel() {
        JPanel loginPanel = new JPanel(new GridLayout(3, 2));

        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);

        loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });

        createAccountButton = new JButton("Create Account");
        createAccountButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createAccount();
            }
        });

        loginPanel.add(new JLabel("Username:"));
        loginPanel.add(usernameField);
        loginPanel.add(new JLabel("Password:"));
        loginPanel.add(passwordField);
        loginPanel.add(loginButton);
        loginPanel.add(createAccountButton);

        return loginPanel;
    }

    private JPanel createClientInputPanel() {
        JPanel clientInputPanel = new JPanel(new GridLayout(5, 2));

        clientNameField = new JTextField(20);
        phoneNumberField = new JTextField(20);
        productNameField = new JTextField(20);  
        quantityField = new JTextField(20);

        sendToAdminButton = new JButton("Send to Admin");
        sendToAdminButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sendToAdmin();
            }
        });

        logoutButton = new JButton("Logout");
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logout();
            }
        });

        clientInputPanel.add(new JLabel("Client Name:"));
        clientInputPanel.add(clientNameField);
        clientInputPanel.add(new JLabel("Phone Number:"));
        clientInputPanel.add(phoneNumberField);
        clientInputPanel.add(new JLabel("Product Name:"));  
        clientInputPanel.add(productNameField);  
        clientInputPanel.add(new JLabel("Quantity:"));
        clientInputPanel.add(quantityField);
        clientInputPanel.add(sendToAdminButton);
        clientInputPanel.add(logoutButton);

        clientInputPanel.setVisible(false);

        return clientInputPanel;
    }

    private List<String> getProductListFromDealer() {
        List<String> productList = new ArrayList<>();
        try (Connection connection = DatabaseManager.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT productName FROM DealerProducts");
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                productList.add(resultSet.getString("productName"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return productList;
    }

    private void login() {
        String enteredUsername = usernameField.getText();
        char[] enteredPassword = passwordField.getPassword();

        try (Connection connection = DatabaseManager.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM Clients WHERE username = ? AND password = ?")) {

            preparedStatement.setString(1, enteredUsername);
            preparedStatement.setString(2, new String(enteredPassword));

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                currentClientUsername = enteredUsername;
                JOptionPane.showMessageDialog(this, "Login successful!");
                getContentPane().getComponent(1).setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password. Please try again.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        passwordField.setText("");
    }

    private void createAccount() {
        String newUsername = usernameField.getText();
        char[] newPassword = passwordField.getPassword();

        if (newUsername.isEmpty() || newPassword.length == 0) {
            JOptionPane.showMessageDialog(this, "Username and password cannot be empty.");
            return;
        }

        try (Connection connection = DatabaseManager.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO Clients(username, password) VALUES (?, ?)")) {

            preparedStatement.setString(1, newUsername);
            preparedStatement.setString(2, new String(newPassword));
            preparedStatement.executeUpdate();

            JOptionPane.showMessageDialog(this, "Account created successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error creating account.");
        }
    }

    private void sendToAdmin() {
        System.out.println("Client Information Sent to Admin:");
        System.out.println("Client Name: " + clientNameField.getText());
        System.out.println("Phone Number: " + phoneNumberField.getText());
        System.out.println("Product: " + productNameField.getText());
        System.out.println("Quantity: " + quantityField.getText());

        try (Connection connection = DatabaseManager.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "INSERT INTO ClientAdminRequests(clientUsername, clientName, phoneNumber, productName, quantity) " +
                             "VALUES (?, ?, ?, ?, ?)")) {

            preparedStatement.setString(1, currentClientUsername);
            preparedStatement.setString(2, clientNameField.getText());
            preparedStatement.setString(3, phoneNumberField.getText());
            preparedStatement.setString(4, productNameField.getText());
            preparedStatement.setInt(5, Integer.parseInt(quantityField.getText()));

            int affectedRows = preparedStatement.executeUpdate();

            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(this, "Information sent to Admin!");
            } else {
                JOptionPane.showMessageDialog(this, "Error sending information to Admin. No rows affected.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error sending information to Admin: " + e.getMessage());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Quantity must be a valid number.");
        }
    }

    private void logout() {
        getContentPane().getComponent(1).setVisible(false);
        new ModuleSelectionFrame();
        dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ClientModule::new);
    }
}
