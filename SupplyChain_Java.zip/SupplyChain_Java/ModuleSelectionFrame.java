import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ModuleSelectionFrame extends JFrame {
    public ModuleSelectionFrame() {
        JButton clientButton = new JButton("Client Module");
        JButton dealerButton = new JButton("Dealer Module");
        JButton adminButton = new JButton("Admin Module");

        clientButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new ClientModule();
                dispose();
            }
        });

        dealerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new DealerModule();
                dispose();
            }
        });

        adminButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                new AdminModule();
                dispose();
            }
        });

        JPanel panel = new JPanel(new GridLayout(3, 1));
        panel.add(clientButton);
        panel.add(dealerButton);
        panel.add(adminButton);

        setContentPane(panel);
        setTitle("Module Selection");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ModuleSelectionFrame::new);
    }
}
