
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DealerModule extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton createAccountButton;

    private JTextField dealerNameField;
    private JTextField phoneNumberField;
    private JTextField productNameField;
    private JTextField quantityField;
    private JButton sendToAdminButton;
    private JButton logoutButton;

    private String currentDealerUsername;

    public DealerModule() {
        setTitle("Dealer Module");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel loginPanel = createLoginPanel();
        JPanel dealerInputPanel = createDealerInputPanel();

        setLayout(new BorderLayout());
        add(loginPanel, BorderLayout.NORTH);
        add(dealerInputPanel, BorderLayout.CENTER);

        setVisible(true);
    }

    private JPanel createLoginPanel() {
        JPanel loginPanel = new JPanel(new GridLayout(3, 2));

        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);

        loginButton = new JButton("Login");
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });

        createAccountButton = new JButton("Create Account");
        createAccountButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                createAccount();
            }
        });

        loginPanel.add(new JLabel("Username:"));
        loginPanel.add(usernameField);
        loginPanel.add(new JLabel("Password:"));
        loginPanel.add(passwordField);
        loginPanel.add(loginButton);
        loginPanel.add(createAccountButton);

        return loginPanel;
    }

    private JPanel createDealerInputPanel() {
        JPanel dealerInputPanel = new JPanel(new GridLayout(5, 2));

        dealerNameField = new JTextField(20);
        phoneNumberField = new JTextField(20);
        productNameField = new JTextField(20);
        quantityField = new JTextField(20);

        sendToAdminButton = new JButton("Send to Admin");
        sendToAdminButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sendToAdmin();
            }
        });

        logoutButton = new JButton("Logout");
        logoutButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                logout();
            }
        });

        dealerInputPanel.add(new JLabel("Dealer Name:"));
        dealerInputPanel.add(dealerNameField);
        dealerInputPanel.add(new JLabel("Phone Number:"));
        dealerInputPanel.add(phoneNumberField);
        dealerInputPanel.add(new JLabel("Product Name:"));
        dealerInputPanel.add(productNameField);
        dealerInputPanel.add(new JLabel("Quantity:"));
        dealerInputPanel.add(quantityField);
        dealerInputPanel.add(sendToAdminButton);
        dealerInputPanel.add(logoutButton);

        dealerInputPanel.setVisible(false);

        return dealerInputPanel;
    }

    private void login() {
        String enteredUsername = usernameField.getText();
        char[] enteredPassword = passwordField.getPassword();

        try (Connection connection = DatabaseManager.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM Dealers WHERE username = ? AND password = ?")) {

            preparedStatement.setString(1, enteredUsername);
            preparedStatement.setString(2, new String(enteredPassword));

            if (preparedStatement.executeQuery().next()) {
                currentDealerUsername = enteredUsername;
                JOptionPane.showMessageDialog(this, "Login successful!");
                getContentPane().getComponent(1).setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password. Please try again.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        passwordField.setText("");
    }

    private void createAccount() {
        String newUsername = usernameField.getText();
        char[] newPassword = passwordField.getPassword();

        if (newUsername.isEmpty() || newPassword.length == 0) {
            JOptionPane.showMessageDialog(this, "Username and password cannot be empty.");
            return;
        }

        try (Connection connection = DatabaseManager.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO Dealers(username, password) VALUES (?, ?)")) {

            preparedStatement.setString(1, newUsername);
            preparedStatement.setString(2, new String(newPassword));
            preparedStatement.executeUpdate();

            JOptionPane.showMessageDialog(this, "Account created successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error creating account.");
        }
    }

    private void sendToAdmin() {
        System.out.println("Dealer Information Sent to Admin:");
        System.out.println("Dealer Name: " + dealerNameField.getText());
        System.out.println("Phone Number: " + phoneNumberField.getText());
        System.out.println("Product Name: " + productNameField.getText());
        System.out.println("Quantity: " + quantityField.getText());

        try (Connection connection = DatabaseManager.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "INSERT INTO DealerAdminRequests(dealerUsername, dealerName, phoneNumber, productName, quantity) " +
                             "VALUES (?, ?, ?, ?, ?)")) {

            preparedStatement.setString(1, currentDealerUsername);
            preparedStatement.setString(2, dealerNameField.getText());
            preparedStatement.setString(3, phoneNumberField.getText());
            preparedStatement.setString(4, productNameField.getText());
            preparedStatement.setInt(5, Integer.parseInt(quantityField.getText()));
            
            int affectedRows = preparedStatement.executeUpdate();


            if (affectedRows > 0) {
                JOptionPane.showMessageDialog(this, "Information sent to Admin!");
            } else {
                JOptionPane.showMessageDialog(this, "Error sending information to Admin. No rows affected.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error sending information to Admin: " + e.getMessage());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Quantity must be a valid number.");
        }
    }

    private void logout() {
        getContentPane().getComponent(1).setVisible(false);
        new ModuleSelectionFrame();
        dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(DealerModule::new);
    }
}
